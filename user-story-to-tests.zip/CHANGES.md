# Recent Changes - Jira API Migration Fix

## Issue
The application was encountering a **410 Gone** error when fetching user stories from Jira:
```
Jira API error: 410 - {"errorMessages":["The requested API has been removed. Please migrate to the /rest/api/3/search/jql API..."]}
```

## Root Cause
The Jira API endpoint `/rest/api/3/search` has been deprecated and removed. Atlassian requires migration to the new `/rest/api/3/search/jql` endpoint.

## Solution Applied
Updated the API endpoint in the JiraService to use the new endpoint path.

### Files Modified
- **File**: `backend/src/services/jiraService.ts`
- **Method**: `getUserStoriesByProject()`
- **Change**: Updated the REST endpoint from `/rest/api/3/search` to `/rest/api/3/search/jql`

### Code Change
```typescript
// OLD (Line 110)
`/rest/api/3/search?jql=${encodedJql}&maxResults=50&fields=...`

// NEW (Line 110)
`/rest/api/3/search/jql?jql=${encodedJql}&maxResults=50&fields=...`
```

## Impact
- ✅ User stories can now be fetched successfully from Jira projects
- ✅ No breaking changes to the application interface
- ✅ Query parameters remain unchanged (JQL, maxResults, fields)
- ✅ Compliant with Atlassian's latest API standards

## Migration Reference
For more details, see: https://developer.atlassian.com/changelog/#CHANGE-2046

## Testing
Test the fix by:
1. Clicking on a Jira project in the UI
2. Verify that user stories load without 410 errors
3. Confirm story details (summary, description, acceptance criteria) display correctly

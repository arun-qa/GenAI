import { Request, Response } from 'express'
import { JiraService } from '../services/jiraService'

export interface JiraConnectionRequest {
  baseUrl: string
  email: string
  apiKey: string
}

export async function connectJira(req: Request, res: Response): Promise<void> {
  try {
    const { baseUrl, email, apiKey } = req.body as JiraConnectionRequest

    if (!baseUrl || !email || !apiKey) {
      res.status(400).json({
        error: 'Missing required fields: baseUrl, email, apiKey'
      })
      return
    }

    const jiraService = new JiraService(baseUrl, email, apiKey)
    const isValid = await jiraService.validateConnection()

    if (!isValid) {
      res.status(401).json({
        error: 'Invalid Jira credentials'
      })
      return
    }

    // Store connection in session (in production, use secure storage like Redis)
    ;(req as any).session.jiraConnection = {
      baseUrl,
      email,
      apiKey,
      connectedAt: new Date()
    }

    res.status(200).json({
      success: true,
      message: 'Successfully connected to Jira'
    })
  } catch (error) {
    console.error('Error connecting to Jira:', error)
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to connect to Jira'
    })
  }
}

export async function getProjects(req: Request, res: Response): Promise<void> {
  try {
    const jiraConnection = (req as any).session?.jiraConnection

    if (!jiraConnection) {
      res.status(401).json({
        error: 'Jira not connected. Please connect first.'
      })
      return
    }

    const jiraService = new JiraService(
      jiraConnection.baseUrl,
      jiraConnection.email,
      jiraConnection.apiKey
    )

    const projects = await jiraService.getProjects()

    res.status(200).json({
      success: true,
      projects
    })
  } catch (error) {
    console.error('Error fetching projects:', error)
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to fetch projects'
    })
  }
}

export async function getUserStories(req: Request, res: Response): Promise<void> {
  try {
    const jiraConnection = (req as any).session?.jiraConnection

    if (!jiraConnection) {
      res.status(401).json({
        error: 'Jira not connected. Please connect first.'
      })
      return
    }

    const { projectKey } = req.query

    const jiraService = new JiraService(
      jiraConnection.baseUrl,
      jiraConnection.email,
      jiraConnection.apiKey
    )

    let stories

    if (projectKey && typeof projectKey === 'string') {
      stories = await jiraService.getUserStoriesByProject(projectKey)
    } else {
      stories = await jiraService.getAllUserStories()
    }

    res.status(200).json({
      success: true,
      stories
    })
  } catch (error) {
    console.error('Error fetching user stories:', error)
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to fetch user stories'
    })
  }
}

export async function disconnectJira(req: Request, res: Response): Promise<void> {
  try {
    ;(req as any).session.jiraConnection = null

    res.status(200).json({
      success: true,
      message: 'Disconnected from Jira'
    })
  } catch (error) {
    console.error('Error disconnecting from Jira:', error)
    res.status(500).json({
      error: error instanceof Error ? error.message : 'Failed to disconnect from Jira'
    })
  }
}

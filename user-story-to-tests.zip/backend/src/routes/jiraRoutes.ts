import { Router } from 'express'
import { connectJira, getProjects, getUserStories, disconnectJira } from '../controllers/jiraController'

const router = Router()

// POST /api/jira/connect - Connect to Jira with credentials
router.post('/connect', connectJira)

// GET /api/jira/projects - Get all Jira projects
router.get('/projects', getProjects)

// GET /api/jira/stories - Get user stories (optionally filtered by projectKey)
router.get('/stories', getUserStories)

// POST /api/jira/disconnect - Disconnect from Jira
router.post('/disconnect', disconnectJira)

export default router

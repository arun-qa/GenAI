// Using native Node.js 18+ fetch API

export interface JiraProject {
  key: string
  name: string
  id: string
}

export interface JiraUserStory {
  key: string
  summary: string
  description: string
  acceptanceCriteria: string
}

export class JiraService {
  private baseUrl: string
  private email: string
  private apiKey: string
  private authHeader: string
  private readonly REQUEST_TIMEOUT = 10000 // 10 seconds

  constructor(baseUrl: string, email: string, apiKey: string) {
    if (!baseUrl?.trim() || !email?.trim() || !apiKey?.trim()) {
      throw new Error('baseUrl, email, and apiKey are required')
    }
    
    this.baseUrl = baseUrl.replace(/\/$/, '') // Remove trailing slash
    this.email = email
    this.apiKey = apiKey
    this.authHeader = Buffer.from(`${email}:${apiKey}`).toString('base64')
  }

  private async makeRequest(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseUrl}${endpoint}`

    const customHeaders = typeof options.headers === 'object' && options.headers
      ? Object.fromEntries(
          Object.entries(options.headers).filter(([key]) => typeof key === 'string')
        )
      : {}

    const headers: Record<string, string> = {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
      'Authorization': `Basic ${this.authHeader}`,
      ...customHeaders
    }

    try {
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), this.REQUEST_TIMEOUT)

      try {
        const response = await fetch(url, {
          ...options,
          headers,
          signal: controller.signal
        })

        clearTimeout(timeoutId)

        if (!response.ok) {
          let errorData: unknown = {}
          try {
            errorData = await response.json()
          } catch {
            errorData = { message: response.statusText }
          }
          throw new Error(`Jira API error: ${response.status} - ${JSON.stringify(errorData)}`)
        }

        const data: unknown = await response.json()
        return data as Record<string, unknown>
      } catch (error) {
        clearTimeout(timeoutId)
        if (error instanceof Error && error.name === 'AbortError') {
          throw new Error(`Request timeout after ${this.REQUEST_TIMEOUT}ms`)
        }
        throw error
      }
    } catch (error) {
      throw new Error(`Failed to make Jira request to ${endpoint}: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  async getProjects(): Promise<JiraProject[]> {
    try {
      const data = await this.makeRequest('/rest/api/3/project?maxResults=50') as any
      
      // Handle both array and paginated response formats
      const projects = Array.isArray(data) ? data : data?.values || []
      
      return projects.map((project: any) => ({
        key: project.key,
        name: project.name,
        id: project.id
      }))
    } catch (error) {
      throw new Error(`Failed to fetch Jira projects: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  async getUserStoriesByProject(projectKey: string): Promise<JiraUserStory[]> {
    try {
      const jql = `project = "${projectKey}" AND type = Story ORDER BY created DESC`
      const encodedJql = encodeURIComponent(jql)

      const data = await this.makeRequest(
        `/rest/api/3/search/jql?jql=${encodedJql}&maxResults=50&fields=summary,description,customfield_10016,customfield_10020,customfield_10021,customfield_10043`
      ) as any

      if (!data?.issues || !Array.isArray(data.issues)) {
        return []
      }

      return data.issues.map((issue: any) => ({
        key: issue.key,
        summary: issue.fields.summary || '',
        description: this.extractDescription(issue.fields.description),
        acceptanceCriteria: this.extractAcceptanceCriteria(issue.fields)
      }))
    } catch (error) {
      throw new Error(`Failed to fetch user stories for project ${projectKey}: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  async getAllUserStories(): Promise<JiraUserStory[]> {
    try {
      const projects = await this.getProjects()
      const allStories: JiraUserStory[] = []
      const errors: string[] = []

      // Fetch stories in parallel with Promise.allSettled for better performance
      const storyPromises = projects.map(project =>
        this.getUserStoriesByProject(project.key)
          .catch(err => {
            errors.push(`Project ${project.key}: ${err instanceof Error ? err.message : 'Unknown error'}`)
            return []
          })
      )

      const results = await Promise.all(storyPromises)
      results.forEach(stories => allStories.push(...stories))

      if (errors.length > 0) {
        console.warn('Warnings while fetching user stories:', errors)
      }

      return allStories
    } catch (error) {
      throw new Error(`Failed to fetch all user stories: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  private extractDescription(descriptionObj: any): string {
    if (!descriptionObj) return ''

    if (typeof descriptionObj === 'string') return descriptionObj

    // Handle Atlassian Document Format (ADF)
    if (descriptionObj.content && Array.isArray(descriptionObj.content)) {
      return descriptionObj.content
        .map((block: any) => {
          if (block.type === 'paragraph' && block.content && Array.isArray(block.content)) {
            return block.content
              .map((item: any) => item.text || '')
              .join(' ')
          }
          return ''
        })
        .filter((text: string) => text.length > 0)
        .join('\n')
    }

    return ''
  }

  private extractAcceptanceCriteria(fields: any): string {
    if (!fields) return ''

    // Try to find acceptance criteria in custom fields
    const customFieldIds = [
      'customfield_10016', // Common Jira field for acceptance criteria
      'customfield_10020',
      'customfield_10021',
      'customfield_10043'
    ]

    for (const fieldId of customFieldIds) {
      const fieldValue = fields[fieldId]
      
      if (fieldValue) {
        // Handle string values
        if (typeof fieldValue === 'string') {
          return fieldValue.trim()
        }

        // Handle rich text (ADF - Atlassian Document Format)
        if (fieldValue.content && Array.isArray(fieldValue.content)) {
          const criteria = fieldValue.content
            .map((block: any) => {
              if (block.type === 'paragraph' && block.content && Array.isArray(block.content)) {
                return block.content
                  .map((item: any) => item.text || '')
                  .join(' ')
              }
              // Handle bullet lists
              if (block.type === 'bulletList' && block.content) {
                return block.content
                  .map((item: any) => {
                    if (item.content && Array.isArray(item.content)) {
                      return '• ' + item.content
                        .map((c: any) => c.text || '')
                        .join(' ')
                    }
                    return ''
                  })
                  .join('\n')
              }
              return ''
            })
            .filter((text: string) => text.length > 0)
            .join('\n')

          if (criteria.trim()) return criteria
        }
      }
    }

    return ''
  }

  async validateConnection(): Promise<boolean> {
    try {
      await this.makeRequest('/rest/api/3/myself')
      return true
    } catch (error) {
      console.error('Jira connection validation failed:', error)
      return false
    }
  }
}

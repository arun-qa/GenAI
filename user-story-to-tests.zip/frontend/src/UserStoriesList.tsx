import { JiraUserStory } from './types'

interface UserStoriesListProps {
  stories: JiraUserStory[]
  onSelectStory: (story: JiraUserStory) => void
  isLoading: boolean
}

function downloadCSV(story: JiraUserStory) {
  const csvContent = [
    ['Field', 'Value'],
    ['Key', story.key],
    ['Summary', story.summary],
    ['Description', story.description],
    ['Acceptance Criteria', story.acceptanceCriteria]
  ]
  
  const csvString = csvContent
    .map(row => 
      row.map(cell => `"${String(cell).replace(/"/g, '""')}"`)
        .join(',')
    )
    .join('\n')
  
  const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' })
  const link = document.createElement('a')
  const url = URL.createObjectURL(blob)
  
  link.setAttribute('href', url)
  link.setAttribute('download', `${story.key}-story.csv`)
  link.style.visibility = 'hidden'
  
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}

export function UserStoriesList({ stories, onSelectStory, isLoading }: UserStoriesListProps) {
  if (isLoading) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '40px',
        color: '#666',
        fontSize: '16px'
      }}>
        Loading user stories from Jira...
      </div>
    )
  }

  if (stories.length === 0) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '40px',
        color: '#999',
        fontSize: '16px'
      }}>
        No user stories found
      </div>
    )
  }

  return (
    <div style={{
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '20px',
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      marginBottom: '30px'
    }}>
      <h2 style={{
        marginBottom: '20px',
        color: '#2c3e50',
        fontSize: '1.5rem'
      }}>
        User Stories from Jira
      </h2>
      <div style={{ display: 'grid', gap: '12px' }}>
        {stories.map((story) => (
          <div
            key={story.key}
            onClick={() => onSelectStory(story)}
            style={{
              padding: '15px',
              border: '2px solid #e1e8ed',
              borderRadius: '6px',
              cursor: 'pointer',
              transition: 'all 0.2s',
              backgroundColor: '#f8f9fa'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = '#3498db'
              e.currentTarget.style.backgroundColor = '#e3f2fd'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = '#e1e8ed'
              e.currentTarget.style.backgroundColor = '#f8f9fa'
            }}
          >
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              gap: '15px'
            }}>
              <div style={{ flex: 1 }}>
                <div style={{
                  fontWeight: '600',
                  color: '#3498db',
                  marginBottom: '8px',
                  fontSize: '14px'
                }}>
                  {story.key}
                </div>
                <div style={{
                  fontSize: '16px',
                  fontWeight: '600',
                  color: '#2c3e50',
                  marginBottom: '8px'
                }}>
                  {story.summary}
                </div>
                {story.description && (
                  <div style={{
                    fontSize: '14px',
                    color: '#666',
                    marginBottom: '8px',
                    lineHeight: '1.5'
                  }}>
                    {story.description.substring(0, 100)}...
                  </div>
                )}
              </div>
              <div style={{
                display: 'flex',
                gap: '10px'
              }}>
                <div style={{
                  padding: '8px 12px',
                  backgroundColor: '#3498db',
                  color: 'white',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: '600',
                  whiteSpace: 'nowrap',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onClick={() => onSelectStory(story)}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#2980b9'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#3498db'
                }}
                >
                  Use This
                </div>
                <div style={{
                  padding: '8px 12px',
                  backgroundColor: '#27ae60',
                  color: 'white',
                  borderRadius: '4px',
                  fontSize: '12px',
                  fontWeight: '600',
                  whiteSpace: 'nowrap',
                  cursor: 'pointer',
                  transition: 'background-color 0.2s'
                }}
                onClick={(e) => {
                  e.stopPropagation()
                  downloadCSV(story)
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.backgroundColor = '#229954'
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.backgroundColor = '#27ae60'
                }}
                >
                  Download CSV
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

import { GenerateRequest, GenerateResponse, JiraUserStory } from './types'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8080/api'

export async function generateTests(request: GenerateRequest): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/generate-tests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
      credentials: 'include'
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data: GenerateResponse = await response.json()
    return data
  } catch (error) {
    console.error('Error generating tests:', error)
    throw error instanceof Error ? error : new Error('Unknown error occurred')
  }
}

// Jira API functions
export async function connectToJira(baseUrl: string, email: string, apiKey: string): Promise<{ success: boolean }> {
  try {
    const response = await fetch(`${API_BASE_URL}/jira/connect`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ baseUrl, email, apiKey }),
      credentials: 'include'
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return { success: data.success }
  } catch (error) {
    console.error('Error connecting to Jira:', error)
    throw error instanceof Error ? error : new Error('Failed to connect to Jira')
  }
}

export async function getJiraProjects(): Promise<{ key: string; name: string; id: string }[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/jira/projects`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include'
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.projects || []
  } catch (error) {
    console.error('Error fetching Jira projects:', error)
    throw error instanceof Error ? error : new Error('Failed to fetch projects')
  }
}

export async function getJiraUserStories(projectKey?: string): Promise<JiraUserStory[]> {
  try {
    const url = new URL(`${API_BASE_URL}/jira/stories`)
    if (projectKey) {
      url.searchParams.append('projectKey', projectKey)
    }

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include'
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return data.stories || []
  } catch (error) {
    console.error('Error fetching user stories:', error)
    throw error instanceof Error ? error : new Error('Failed to fetch user stories')
  }
}

export async function disconnectFromJira(): Promise<{ success: boolean }> {
  try {
    const response = await fetch(`${API_BASE_URL}/jira/disconnect`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include'
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data = await response.json()
    return { success: data.success }
  } catch (error) {
    console.error('Error disconnecting from Jira:', error)
    throw error instanceof Error ? error : new Error('Failed to disconnect from Jira')
  }
}
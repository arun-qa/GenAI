interface JiraProject {
  key: string
  name: string
  id: string
}

interface JiraProjectsListProps {
  projects: JiraProject[]
  selectedProject: string | null
  onSelectProject: (projectKey: string) => void
  isLoading: boolean
}

export function JiraProjectsList({
  projects,
  selectedProject,
  onSelectProject,
  isLoading
}: JiraProjectsListProps) {
  if (isLoading) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '40px',
        color: '#666',
        fontSize: '16px'
      }}>
        Loading projects from Jira...
      </div>
    )
  }

  if (projects.length === 0) {
    return (
      <div style={{
        textAlign: 'center',
        padding: '40px',
        color: '#999',
        fontSize: '16px'
      }}>
        No projects found
      </div>
    )
  }

  return (
    <div style={{
      backgroundColor: 'white',
      borderRadius: '8px',
      padding: '20px',
      boxShadow: '0 2px 10px rgba(0,0,0,0.1)',
      marginBottom: '20px'
    }}>
      <h3 style={{
        marginBottom: '15px',
        color: '#2c3e50',
        fontSize: '1.2rem'
      }}>
        Select a Project
      </h3>
      <div>
        <select
          value={selectedProject || ''}
          onChange={(e) => onSelectProject(e.target.value)}
          style={{
            width: '100%',
            padding: '12px',
            fontSize: '16px',
            border: '2px solid #e1e8ed',
            borderRadius: '6px',
            backgroundColor: 'white',
            cursor: 'pointer',
            transition: 'border-color 0.2s',
            color: '#2c3e50',
            fontWeight: '500'
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = '#3498db'
            e.currentTarget.style.outline = 'none'
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = '#e1e8ed'
          }}
        >
          <option value="">-- Choose a project --</option>
          {projects.map((project) => (
            <option key={project.id} value={project.key}>
              {project.key} - {project.name}
            </option>
          ))}
        </select>
      </div>
    </div>
  )
}
